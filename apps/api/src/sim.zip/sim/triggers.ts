import type {
  BattleEventType,
  BattleItem,
  BattleState,
  RuntimeEffect,
  SimulationConfig,
} from "./types.js";
import { resolveEffect } from "./effects.js";

export function resolveFightStartEffects(
  state: BattleState,
  config: SimulationConfig
): void {
  for (const item of state.items) {
    for (const effect of item.effects) {
      if (shouldResolveAtFightStart(item, effect)) {
        resolveEffect(state, item, effect, config, resolveTriggeredEffects);
      }
    }
  }
}

export function resolveTriggeredEffects(
  state: BattleState,
  eventType: BattleEventType,
  eventSource: BattleItem,
  config: SimulationConfig
): void {
  for (const item of state.items) {
    if (item.isDestroyed) continue;

    for (const effect of item.effects) {
      if (!effect.condition) continue;

      if (conditionMatchesEvent(effect.condition, eventType, eventSource, item)) {
        resolveEffect(state, item, effect, config, resolveTriggeredEffects);
      }
    }
  }
}

function shouldResolveAtFightStart(item: BattleItem, effect: RuntimeEffect): boolean {
  if (effect.condition) {
    const condition = effect.condition.toLowerCase();

    if (
      condition.includes("start of each fight") ||
      condition.includes("start of the fight") ||
      condition.startsWith("for each")
    ) {
      return true;
    }

    return false;
  }

  // Items without cooldown are usually passive/shop-board modifiers. Apply their
  // non-damaging stat modifiers at fight start so passive cards like Star Chart
  // can affect adjacent items without requiring an ITEM_USED event.
  if (isPassiveRuntimeStatText(effect.rawText)) return true;

  if (item.cooldownSeconds !== null) return false;

  return isPassiveFightStartEffect(effect);
}

function isPassiveRuntimeStatText(rawText: string): boolean {
  return /\b(this|your|adjacent).+\b(has|have|are affected|cooldowns are|for each|for every)\b/i.test(rawText) || /\bfor each\b|\bfor every\b/i.test(rawText);
}

function isPassiveFightStartEffect(effect: RuntimeEffect): boolean {
  return (
    effect.kind === "DAMAGE" ||
    effect.kind === "SHIELD" ||
    effect.kind === "HEAL" ||
    effect.kind === "BURN" ||
    effect.kind === "POISON" ||
    effect.kind === "REGEN" ||
    effect.kind === "COOLDOWN_MOD" ||
    effect.kind === "MULTICAST_MOD" ||
    effect.kind === "CRIT_CHANCE_MOD" ||
    effect.kind === "CRIT_DAMAGE_MOD" ||
    effect.kind === "VALUE_MOD" ||
    effect.kind === "LIFESTEAL_MOD" ||
    effect.kind === "MAX_HEALTH_MOD" ||
    effect.kind === "MAX_AMMO_MOD" ||
    effect.kind === "AMMO_MOD" ||
    effect.kind === "TAG_MOD" ||
    effect.kind === "HASTE" ||
    effect.kind === "SLOW" ||
    effect.kind === "FREEZE" ||
    effect.kind === "CHILL" ||
    effect.kind === "HEAT" ||
    effect.kind === "INVULNERABILITY"
  );
}

export function conditionMatchesEvent(
  condition: string,
  eventType: BattleEventType,
  eventSource: BattleItem,
  effectOwner: BattleItem
): boolean {
  const lower = condition.toLowerCase();

  const sourceIsSelf = eventSource.instanceId === effectOwner.instanceId;

  if (lower.includes("this") && !sourceIsSelf) {
    return false;
  }

  if (eventType === "ITEM_USED") {
    if (lower.includes("use") || lower.includes("uses")) return true;
  }

  if (eventType === "BURN_APPLIED") {
    if (lower.includes("burn")) return true;
  }

  if (eventType === "BURN_DAMAGE_DEALT") {
    if (lower.includes("burn") && lower.includes("damage")) return true;
  }

  if (eventType === "POISON_APPLIED") {
    if (lower.includes("poison")) return true;
  }

  if (eventType === "POISON_DAMAGE_DEALT") {
    if (lower.includes("poison") && lower.includes("damage")) return true;
  }

  if (eventType === "SLOW_APPLIED") {
    if (lower.includes("slow")) return true;
  }

  if (eventType === "HASTE_APPLIED") {
    if (lower.includes("haste")) return true;
  }

  if (eventType === "FREEZE_APPLIED") {
    if (lower.includes("freeze")) return true;
  }

  if (eventType === "CHARGE_APPLIED") {
    if (lower.includes("charge")) return true;
  }

  if (eventType === "FLYING_STARTED") {
    if (lower.includes("start") && lower.includes("flying")) return true;
  }

  if (eventType === "FLYING_STOPPED") {
    if (lower.includes("stop") && lower.includes("flying")) return true;
  }

  if (eventType === "ITEM_DESTROYED") {
    if (lower.includes("destroy")) return true;
  }

  if (eventType === "ITEM_REPAIRED") {
    if (lower.includes("repair")) return true;
  }

  return false;
}
